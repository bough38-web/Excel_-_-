라이선스 파일: license.lic (JSON)
예시:
{
  "expiry": "2026-12-31",
  "type": "enterprise"
}
관리자 패널: python admin_panel.py 또는 프로그램 메뉴 '관리>관리자 패널'

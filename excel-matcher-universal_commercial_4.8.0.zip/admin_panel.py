import tkinter as tk
from tkinter import ttk, messagebox
from license_manager import save_license, load_license

class AdminPanel(tk.Toplevel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.title("관리자 - 라이선스 설정")
        self.geometry("360x240")
        self.resizable(False, False)

        frm = ttk.Frame(self, padding=14)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="만료일 (YYYY-MM-DD)").grid(row=0, column=0, sticky="w")
        self.ent_expiry = ttk.Entry(frm, width=20)
        self.ent_expiry.grid(row=0, column=1, pady=6, sticky="w")

        ttk.Label(frm, text="라이선스 타입").grid(row=1, column=0, sticky="w")
        self.type_var = tk.StringVar(value="personal")
        ttk.Combobox(frm, textvariable=self.type_var, values=["personal","enterprise"], state="readonly", width=17)                .grid(row=1, column=1, pady=6, sticky="w")

        ttk.Button(frm, text="저장", command=self.on_save).grid(row=2, column=0, columnspan=2, pady=14, sticky="ew")
        ttk.Button(frm, text="닫기", command=self.destroy).grid(row=3, column=0, columnspan=2, sticky="ew")

        # load current
        lic = load_license() or {}
        if lic.get("expiry"): self.ent_expiry.insert(0, lic["expiry"])
        if lic.get("type") in ("personal","enterprise"): self.type_var.set(lic["type"])

    def on_save(self):
        expiry = self.ent_expiry.get().strip()
        lic_type = self.type_var.get().strip()
        try:
            # basic validation
            import datetime
            datetime.datetime.strptime(expiry, "%Y-%m-%d")
        except Exception:
            messagebox.showerror("오류", "만료일 형식이 올바르지 않습니다. 예: 2026-12-31")
            return
        save_license(expiry, lic_type)
        messagebox.showinfo("완료", "라이선스 저장 완료")

def main():
    root = tk.Tk()
    root.withdraw()
    win = AdminPanel(root)
    win.mainloop()

if __name__ == "__main__":
    main()

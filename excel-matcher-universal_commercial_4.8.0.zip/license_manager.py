import json, os, datetime
from commercial_config import LICENSE_FILE

def load_license():
    if not os.path.exists(LICENSE_FILE):
        return None
    try:
        with open(LICENSE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def validate_license():
    lic = load_license()
    if not lic:
        return False, "라이선스 파일 없음", None

    expiry_s = lic.get("expiry")
    lic_type = (lic.get("type") or "personal").lower()
    try:
        expiry = datetime.datetime.strptime(expiry_s, "%Y-%m-%d").date()
    except Exception:
        return False, "라이선스 형식 오류(expiry)", None

    today = datetime.date.today()
    if today > expiry:
        return False, f"라이선스 만료 ({expiry})", None

    if lic_type not in ("personal", "enterprise"):
        lic_type = "personal"

    return True, "OK", {"type": lic_type, "expiry": expiry_s}

def save_license(expiry: str, lic_type: str):
    lic = {"expiry": expiry, "type": lic_type}
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(lic, f, ensure_ascii=False, indent=2)
    return lic

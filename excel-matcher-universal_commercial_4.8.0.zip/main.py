import sys
import tkinter as tk
from tkinter import messagebox
from ui import App
from license_manager import validate_license
from commercial_config import ADMIN_PASSWORD
from admin_panel import AdminPanel

def try_open_admin():
    import tkinter.simpledialog as sd
    pw = sd.askstring("관리자", "관리자 비밀번호를 입력하세요:", show="*")
    if pw != ADMIN_PASSWORD:
        messagebox.showerror("오류", "비밀번호가 올바르지 않습니다.")
        return False
    root = tk.Tk(); root.withdraw(); AdminPanel(root); root.mainloop()
    return True

if __name__ == "__main__":
    ok, msg, info = validate_license()
    if not ok:
        root = tk.Tk(); root.withdraw()
        if messagebox.askyesno("라이선스 오류", f"{msg}\n\n관리자 패널을 열어 라이선스를 생성/수정할까요?"):
            try_open_admin()
        root.destroy()
        # 재검증
        ok, msg, info = validate_license()
        if not ok:
            r = tk.Tk(); r.withdraw()
            messagebox.showerror("라이선스 오류", f"{msg}\n\nlicense.lic 파일을 프로그램 폴더에 두세요.")
            r.destroy()
            sys.exit(1)

    app = App(license_info=info)
    app.mainloop()

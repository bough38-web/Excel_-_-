from __future__ import annotations
import os, json, tkinter as tk, traceback
from tkinter import ttk, filedialog, messagebox, simpledialog

from __version__ import __version__
from diagnostics import collect_summary, format_summary
from excel_io import read_header_file, get_sheet_names
from open_excel import list_open_books, list_sheets, read_header_open, XLWINGS_AVAILABLE
from matcher import match_universal
from commercial_config import ADMIN_PASSWORD
from admin_panel import AdminPanel


APP_TITLE = f"Excel 매칭 도구 (Universal) v{__version__}"
OUT_DIR = os.path.join(os.getcwd(), "outputs")
PRESET_FILE = os.path.join(os.getcwd(), "presets.json")
REPLACE_FILE = os.path.join(os.getcwd(), "replacements.json")
os.makedirs(OUT_DIR, exist_ok=True)

def _load_replace_file():
    try:
        if os.path.exists(REPLACE_FILE):
            with open(REPLACE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and "presets" not in data:
                return {"presets": data, "active": {}, "active_name": ""}
            return {
                "presets": data.get("presets", {}) or {},
                "active": data.get("active", {}) or {},
                "active_name": data.get("active_name", "") or ""
            }
    except:
        pass
    return {"presets": {}, "active": {}, "active_name": ""}

def _save_replace_file(presets: dict, active: dict, active_name: str = ""):
    with open(REPLACE_FILE, "w", encoding="utf-8") as f:
        json.dump({"presets": presets or {}, "active": active or {}, "active_name": active_name or ""}, f, ensure_ascii=False, indent=4)

class ReplacementEditor(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("🛠️ 데이터 치환 규칙 설정")
        self.geometry("650x520")

        data = _load_replace_file()
        self.presets = data["presets"]
        self.rules = data["active"] or {}
        self.active_name = data.get("active_name", "") or ""

        top_frame = ttk.LabelFrame(self, text="규칙 프리셋 관리", padding=10)
        top_frame.pack(fill="x", padx=10, pady=5)

        self.preset_var = tk.StringVar()
        self.cb_preset = ttk.Combobox(top_frame, textvariable=self.preset_var, state="readonly", width=25)
        self.cb_preset.pack(side="left", padx=5)
        self.cb_preset.bind("<<ComboboxSelected>>", self.on_preset_selected)

        ttk.Button(top_frame, text="현재 규칙 저장", command=self.save_preset).pack(side="left", padx=2)
        ttk.Button(top_frame, text="삭제", command=self.delete_preset).pack(side="left", padx=2)
        ttk.Button(top_frame, text="초기화", command=self.clear_all).pack(side="right", padx=2)

        main_frame = ttk.Frame(self, padding=10); main_frame.pack(fill="both", expand=True)
        form_frame = ttk.Frame(main_frame); form_frame.pack(fill="x", pady=(0, 10))

        ttk.Label(form_frame, text="대상 컬럼명:").grid(row=0, column=0, padx=5, sticky="w")
        self.ent_col = ttk.Entry(form_frame, width=20); self.ent_col.grid(row=0, column=1, padx=5)
        ttk.Label(form_frame, text="변경 전 (Old):").grid(row=0, column=2, padx=5, sticky="w")
        self.ent_old = ttk.Entry(form_frame, width=15); self.ent_old.grid(row=0, column=3, padx=5)
        ttk.Label(form_frame, text="변경 후 (New):").grid(row=0, column=4, padx=5, sticky="w")
        self.ent_new = ttk.Entry(form_frame, width=15); self.ent_new.grid(row=0, column=5, padx=5)
        ttk.Button(form_frame, text="추가/수정", command=self.add_rule).grid(row=0, column=6, padx=10)

        columns = ("col", "old", "new")
        self.tree = ttk.Treeview(main_frame, columns=columns, show="headings", height=15)
        self.tree.heading("col", text="대상 컬럼")
        self.tree.heading("old", text="변경 전 값 (Old)")
        self.tree.heading("new", text="변경 후 값 (New)")
        self.tree.column("col", width=180); self.tree.column("old", width=180); self.tree.column("new", width=180)

        scroll = ttk.Scrollbar(main_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True); scroll.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", self.on_double_click)

        bot_frame = ttk.Frame(self, padding=10); bot_frame.pack(fill="x")
        ttk.Label(bot_frame, text="* 목록을 더블클릭하면 삭제됩니다.", foreground="gray").pack(side="left")
        ttk.Button(bot_frame, text="닫기 (적용)", command=self._close).pack(side="right")

        self.update_preset_cb(); self.refresh_tree()

    def _persist(self):
        name = self.cb_preset.get() if self.cb_preset.get() in self.presets else self.active_name
        _save_replace_file(self.presets, self.rules, name)

    def _close(self):
        self._persist()
        self.destroy()

    def add_rule(self):
        col = self.ent_col.get().strip(); old = self.ent_old.get().strip(); new = self.ent_new.get().strip()
        if not col or not old:
            messagebox.showwarning("입력 오류", "컬럼명과 변경 전 값은 필수입니다."); return
        self.rules.setdefault(col, {})[old] = new
        self.refresh_tree()
        self.ent_old.delete(0, tk.END); self.ent_new.delete(0, tk.END); self.ent_old.focus()
        self._persist()

    def refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        for col, mapping in self.rules.items():
            if not isinstance(mapping, dict): continue
            for old, new in mapping.items():
                self.tree.insert("", "end", values=(col, old, new))

    def on_double_click(self, event=None):
        item = self.tree.selection()
        if not item: return
        col, old, new = self.tree.item(item, "values")
        if messagebox.askyesno("삭제", f"'{col}' 컬럼의 '{old}' -> '{new}' 규칙을 삭제할까요?"):
            if col in self.rules and old in self.rules[col]:
                del self.rules[col][old]
                if not self.rules[col]:
                    del self.rules[col]
            self.refresh_tree(); self._persist()

    def clear_all(self):
        if messagebox.askyesno("초기화", "모든 규칙을 지우시겠습니까?"):
            self.rules = {}; self.refresh_tree(); self._persist()

    def update_preset_cb(self):
        names = list(self.presets.keys())
        self.cb_preset["values"] = names
        self.cb_preset.set("설정을 선택하세요" if names else "저장된 설정 없음")

    def save_preset(self):
        if not self.rules:
            messagebox.showwarning("경고", "저장할 규칙이 없습니다."); return
        name = simpledialog.askstring("설정 저장", "치환 규칙 세트 이름 입력:")
        if not name: return
        name = name.strip()
        if not name: return
        import copy
        self.presets[name] = copy.deepcopy(self.rules)
        self.active_name = name
        self.cb_preset.set(name)
        self.update_preset_cb(); self._persist()
        messagebox.showinfo("저장", f"[{name}] 규칙이 저장되었습니다.")

    def delete_preset(self):
        name = self.cb_preset.get()
        if name in self.presets and messagebox.askyesno("삭제", f"[{name}] 규칙 세트를 삭제하시겠습니까?"):
            del self.presets[name]
            if self.active_name == name: self.active_name = ""
            self.update_preset_cb(); self._persist()

    def on_preset_selected(self, event=None):
        name = self.cb_preset.get()
        if name in self.presets:
            import copy
            self.rules = copy.deepcopy(self.presets[name])
            self.active_name = name
            self.refresh_tree(); self._persist()

    def get_rules(self): return self.rules

class MultiSelectListBox(ttk.Frame):
    def __init__(self, master, height=5):
        super().__init__(master)
        self.listbox = tk.Listbox(self, selectmode="multiple", height=height, exportselection=False)
        sb = ttk.Scrollbar(self, orient="vertical", command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=sb.set)
        self.listbox.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        ttk.Label(self, text="(Ctrl/Shift+클릭으로 다중 선택)", font=("맑은 고딕", 8), foreground="gray").pack(side="bottom", anchor="w")
    def set_items(self, items):
        self.listbox.delete(0, tk.END)
        for it in items: self.listbox.insert(tk.END, it)
    def get_selected(self):
        return [self.listbox.get(i) for i in self.listbox.curselection()]
    def select_item(self, item):
        self.listbox.selection_clear(0, tk.END)
        try:
            idx = self.listbox.get(0, tk.END).index(item)
            self.listbox.selection_set(idx); self.listbox.see(idx)
        except ValueError:
            pass

class SourceFrame(ttk.LabelFrame):
    def __init__(self, master, title, mode_var, on_change=None, is_base=False):
        super().__init__(master, text=title, padding=10)
        self.mode = mode_var; self.on_change = on_change; self.is_base = is_base
        self.path = tk.StringVar(); self.book = tk.StringVar(); self.sheet = tk.StringVar(); self.header = tk.IntVar(value=1)

        top = ttk.Frame(self); top.pack(fill="x", pady=(0, 5))
        ttk.Radiobutton(top, text="파일 불러오기", value="file", variable=self.mode, command=self._refresh_ui).pack(side="left", padx=(0,10))
        ttk.Radiobutton(top, text="열려있는 엑셀", value="open", variable=self.mode, command=self._refresh_ui).pack(side="left")
        ttk.Button(top, text="새로고침", command=self.refresh_open).pack(side="right")

        self.f_frame = ttk.Frame(self)
        ttk.Entry(self.f_frame, textvariable=self.path).pack(side="left", fill="x", expand=True)
        ttk.Button(self.f_frame, text="찾기", command=self._pick_file).pack(side="left", padx=5)

        self.o_frame = ttk.Frame(self)
        self.cb_book = ttk.Combobox(self.o_frame, textvariable=self.book, state="readonly")
        self.cb_book.pack(side="left", fill="x", expand=True)
        self.cb_book.bind("<<ComboboxSelected>>", self._on_book_select)

        self.c_frame = ttk.Frame(self); self.c_frame.pack(fill="x", pady=(5,5))
        ttk.Label(self.c_frame, text="시트:").pack(side="left")
        self.cb_sheet = ttk.Combobox(self.c_frame, textvariable=self.sheet, state="readonly", width=18)
        self.cb_sheet.pack(side="left", padx=5)
        self.cb_sheet.bind("<<ComboboxSelected>>", self._notify_change)

        ttk.Label(self.c_frame, text="헤더:").pack(side="left", padx=(10,0))
        ttk.Spinbox(self.c_frame, from_=1, to=99, textvariable=self.header, width=5, command=self._notify_change).pack(side="left", padx=5)

        if self.is_base:
            key_frame = ttk.LabelFrame(self, text="🔑 매칭 키 (Key) 선택", padding=5)
            key_frame.pack(fill="x", pady=(5,0))
            self.key_listbox = MultiSelectListBox(key_frame, height=4)
            self.key_listbox.pack(fill="x")

        self._refresh_ui()

    def _refresh_ui(self):
        if self.mode.get() == "file":
            self.o_frame.pack_forget(); self.f_frame.pack(fill="x", before=self.c_frame)
        else:
            self.f_frame.pack_forget(); self.o_frame.pack(fill="x", before=self.c_frame); self.refresh_open()
        self._notify_change()

    def _pick_file(self):
        p = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx *.xls *.csv"), ("All", "*.*")])
        if not p: return
        self.path.set(p)
        try:
            self.cb_sheet['values'] = get_sheet_names(p)
            if self.cb_sheet['values']: self.cb_sheet.current(0)
        except:
            pass
        self._notify_change()

    def refresh_open(self):
        if self.mode.get() != "open": return
        if not XLWINGS_AVAILABLE:
            messagebox.showwarning(
                "열려있는 엑셀 모드 불가",
                "xlwings/Excel 연동이 불가능합니다.\n\n"
                "• Excel 설치 확인\n• xlwings 설치(pip)\n• macOS: Automation 권한 허용\n\n"
                "파일 모드로 사용하거나 설치 후 다시 시도하세요."
            )
            self.cb_book['values'] = []
            return
        books = list_open_books()
        self.cb_book['values'] = books
        if books and not self.book.get(): self.book.set(books[0])
        self._on_book_select()

    def _on_book_select(self, event=None):
        if not self.book.get(): return
        try:
            sheets = list_sheets(self.book.get())
            self.cb_sheet['values'] = sheets
            if sheets: self.cb_sheet.current(0)
        except Exception as e:
            messagebox.showerror("시트 조회 실패", str(e))
        self._notify_change()

    def _notify_change(self, event=None):
        if self.on_change: self.on_change()

    def get_config(self):
        return {"type": self.mode.get(), "path": self.path.get(), "book": self.book.get(), "sheet": self.sheet.get(), "header": int(self.header.get())}

    def get_selected_keys(self):
        return self.key_listbox.get_selected() if self.is_base and hasattr(self, "key_listbox") else []

class GridCheckList(ttk.Frame):
    def __init__(self, master, columns=4, height=300):
        super().__init__(master)
        self.columns = columns; self.vars = {}
        top = ttk.Frame(self); top.pack(fill="x", pady=(0,4))
        self.q = tk.StringVar()
        ent = ttk.Entry(top, textvariable=self.q); ent.pack(side="left", fill="x", expand=True)
        ent.bind("<KeyRelease>", lambda e: self._filter())
        ttk.Button(top, text="지우기", width=6, command=self._clear).pack(side="left", padx=4)

        self.canvas = tk.Canvas(self, height=height, bg="white", highlightthickness=0)
        sb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas)
        self.inner_id = self.canvas.create_window((0,0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=sb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.inner_id, width=e.width))
        self.all_items = []

    def set_items(self, items):
        self.all_items = items; self.vars.clear()
        for w in self.inner.winfo_children(): w.destroy()
        if not items:
            ttk.Label(self.inner, text="(데이터 없음)").pack(); return
        for it in items: self.vars[it] = tk.BooleanVar(value=False)
        self._render(items)

    def _render(self, items):
        for w in self.inner.winfo_children(): w.destroy()
        for idx, it in enumerate(items):
            cb = ttk.Checkbutton(self.inner, text=it, variable=self.vars[it])
            cb.grid(row=idx//self.columns, column=idx%self.columns, sticky="w", padx=4, pady=2)
        for i in range(self.columns): self.inner.columnconfigure(i, weight=1)

    def checked(self): return [k for k,v in self.vars.items() if v.get()]
    def check_all(self): 
        for v in self.vars.values(): v.set(True)
    def uncheck_all(self):
        for v in self.vars.values(): v.set(False)
    def set_checked_items(self, items):
        self.uncheck_all(); cnt=0
        for it in items:
            if it in self.vars:
                self.vars[it].set(True); cnt += 1
        return cnt
    def _clear(self):
        self.q.set(""); self._render(self.all_items)
    def _filter(self):
        q=(self.q.get() or "").strip().lower()
        self._render([it for it in self.all_items if q in it.lower()] if q else self.all_items)

class App(tk.Tk):
    def __init__(self, license_info=None):
        super().__init__()
        self.license_info = license_info or {'type':'personal','expiry':'-'}
        self.title(APP_TITLE)
        self.geometry("1050x980")

        self.base_mode = tk.StringVar(value="open")
        self.tgt_mode = tk.StringVar(value="file")
        self.presets = {}
        self.opt_fuzzy = tk.BooleanVar(value=False)
        self.opt_color = tk.BooleanVar(value=True)
        self.replacer_win = None
        # 메뉴바 (관리자 패널 포함)
        menubar = tk.Menu(self)
        manage_menu = tk.Menu(menubar, tearoff=0)
        def open_admin():
            pw = simpledialog.askstring('관리자', '관리자 비밀번호:', show='*')
            if pw != ADMIN_PASSWORD:
                messagebox.showerror('오류', '비밀번호가 올바르지 않습니다.')
                return
            AdminPanel(self)
        manage_menu.add_command(label='관리자 패널', command=open_admin)
        manage_menu.add_separator()
        manage_menu.add_command(label=f"라이선스: {self.license_info.get('type','?')} / 만료: {self.license_info.get('expiry','?')}", state='disabled')
        menubar.add_cascade(label='관리', menu=manage_menu)
        self.config(menu=menubar)

        self._init_ui()
        self.load_presets()

        self._log("환경 진단:")
        self._log(format_summary(collect_summary()))

    def _init_ui(self):
        try: ttk.Style(self).theme_use("clam")
        except: pass
        main = ttk.Frame(self, padding=15); main.pack(fill="both", expand=True)

        self.base_ui = SourceFrame(main, "1. 기준 데이터 (Key 보유)", self.base_mode, is_base=True)
        self.base_ui.pack(fill="x", pady=(0,10))
        self.tgt_ui = SourceFrame(main, "2. 대상 데이터 (데이터 가져올 곳)", self.tgt_mode)
        self.tgt_ui.pack(fill="x", pady=(0,10))
        self.base_ui.on_change = self._load_base_cols
        self.tgt_ui.on_change = self._load_tgt_cols

        preset_frame = ttk.Frame(main); preset_frame.pack(fill="x", pady=(5,5))
        ttk.Label(preset_frame, text="📌 자주 쓰는 컬럼:", font=("맑은 고딕", 9, "bold")).pack(side="left")
        self.cb_preset = ttk.Combobox(preset_frame, state="readonly", width=25)
        self.cb_preset.pack(side="left", padx=5)
        self.cb_preset.bind("<<ComboboxSelected>>", self.apply_preset)
        ttk.Button(preset_frame, text="현재 선택 저장", command=self.save_preset).pack(side="left", padx=2)
        ttk.Button(preset_frame, text="삭제", command=self.delete_preset).pack(side="left", padx=2)

        ttk.Label(main, text="가져올 컬럼 선택 (4열 보기):", font=("bold", 10)).pack(anchor="w", pady=(5,0))
        self.col_list = GridCheckList(main, height=250); self.col_list.pack(fill="both", expand=True)

        btns = ttk.Frame(main); btns.pack(fill="x", pady=5)
        ttk.Button(btns, text="✅ 전체 선택", command=self.col_list.check_all).pack(side="left", fill="x", expand=True, padx=(0,2))
        ttk.Button(btns, text="🔄 선택 초기화", command=self.col_list.uncheck_all).pack(side="left", fill="x", expand=True, padx=(2,0))

        opt_frame = ttk.LabelFrame(main, text="⚙️ 고급 설정", padding=10); opt_frame.pack(fill="x", pady=(5,0))
        ttk.Button(opt_frame, text="🛠️ 데이터 치환 설정 (Find & Replace)", command=self.open_replacer).pack(side="left", padx=(0,20))
        ttk.Checkbutton(opt_frame, text="🤖 오타 보정", variable=self.opt_fuzzy).pack(side="left", padx=(0,10))
        ttk.Checkbutton(opt_frame, text="🎨 색상 강조", variable=self.opt_color).pack(side="left")

        ttk.Button(main, text="매칭 실행 (RUN)", command=self.run).pack(fill="x", pady=10, ipady=5)
        self.log_txt = tk.Text(main, height=7, state="disabled", bg="#f0f0f0"); self.log_txt.pack(fill="x")

        self._load_base_cols(); self._load_tgt_cols()

    def _log(self, msg):
        self.log_txt.config(state="normal")
        self.log_txt.insert("end", f"- {msg}
")
        self.log_txt.see("end")
        self.log_txt.config(state="disabled")
        self.update_idletasks()

    def open_replacer(self):
        if self.replacer_win is None or not self.replacer_win.winfo_exists():
            self.replacer_win = ReplacementEditor(self)
        else:
            self.replacer_win.lift()

    def load_presets(self):
        try:
            if os.path.exists(PRESET_FILE):
                with open(PRESET_FILE,"r",encoding="utf-8") as f:
                    self.presets=json.load(f)
            else:
                self.presets={}
        except:
            self.presets={}
        self.cb_preset["values"]=list(self.presets.keys())
        self.cb_preset.set("설정을 선택하세요" if self.presets else "저장된 설정 없음")

    def _save_presets(self):
        with open(PRESET_FILE,"w",encoding="utf-8") as f:
            json.dump(self.presets, f, ensure_ascii=False, indent=4)

    def save_preset(self):
        checked=self.col_list.checked()
        if not checked:
            messagebox.showwarning("경고","저장할 컬럼을 하나 이상 체크해주세요."); return
        name=simpledialog.askstring("설정 저장","이 설정의 이름을 입력하세요:
(예: 급여대장용)")
        if not name: return
        name=name.strip()
        if not name: return
        self.presets[name]=checked
        self._save_presets()
        self.load_presets()
        self.cb_preset.set(name)
        messagebox.showinfo("저장 완료", f"[{name}] 설정이 저장되었습니다.")

    def delete_preset(self):
        name=self.cb_preset.get()
        if name in self.presets and messagebox.askyesno("삭제 확인", f"정말 [{name}] 설정을 삭제하시겠습니까?"):
            del self.presets[name]
            self._save_presets()
            self.load_presets()

    def apply_preset(self, event=None):
        name=self.cb_preset.get()
        if name in self.presets:
            cnt=self.col_list.set_checked_items(self.presets[name])
            self._log(f"프리셋 [{name}] 적용됨 ({cnt}개 항목 선택)")

    def _load_base_cols(self):
        cfg=self.base_ui.get_config()
        if not cfg.get("sheet"): return
        try:
            if cfg["type"]=="file":
                if not cfg["path"] or not os.path.exists(cfg["path"]): return
                cols=read_header_file(cfg["path"], cfg["sheet"], cfg["header"])
            else:
                if not cfg["book"]: return
                cols=read_header_open(cfg["book"], cfg["sheet"], cfg["header"])
            self.base_ui.key_listbox.set_items(cols)
            if cols: self.base_ui.key_listbox.select_item(cols[0])
        except Exception as e:
            self._log(f"기준 헤더 로드 실패: {e}")

    def _load_tgt_cols(self):
        cfg=self.tgt_ui.get_config()
        if not cfg.get("sheet"): return
        try:
            if cfg["type"]=="file":
                if not cfg["path"] or not os.path.exists(cfg["path"]): return
                cols=read_header_file(cfg["path"], cfg["sheet"], cfg["header"])
            else:
                if not cfg["book"]: return
                cols=read_header_open(cfg["book"], cfg["sheet"], cfg["header"])
            self.col_list.set_items(cols)
            self._log(f"대상 컬럼 로드됨 ({len(cols)}개)")
        except Exception as e:
            self._log(f"대상 헤더 로드 실패: {e}")

    def run(self):
        try:
            b_cfg=self.base_ui.get_config()
            t_cfg=self.tgt_ui.get_config()
            keys=self.base_ui.get_selected_keys()
            take=self.col_list.checked()
            if not keys:
                messagebox.showwarning("경고","매칭할 키(Key)를 하나 이상 선택하세요."); return
            if not take:
                messagebox.showwarning("경고","가져올 컬럼을 선택하세요."); return
            options={"fuzzy": self.opt_fuzzy.get(), "color": self.opt_color.get()}
            replace_rules = (self.replacer_win.get_rules() if self.replacer_win and self.replacer_win.winfo_exists()
                             else _load_replace_file().get("active", {}) or {})
            out_path, summary = match_universal(b_cfg, t_cfg, keys, take, OUT_DIR, options, replace_rules, self._log)
            messagebox.showinfo("성공", f"✅ 작업 완료!

[결과 리포트]
{summary}

📂 저장 위치:
{os.path.basename(out_path)}")
        except Exception as e:
            traceback.print_exc()
            msg=str(e)
            if "xlwings" in msg.lower():
                msg += "

[힌트]
- Excel 설치 확인
- macOS: Automation 권한 허용
- 파일 모드로 사용 가능"
            messagebox.showerror("오류", f"실행 중 오류:
{msg}")
            self._log(f"Error: {msg}")

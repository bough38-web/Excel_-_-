from __future__ import annotations
import pandas as pd
import numpy as np

SUCCESS_COLOR = (226, 239, 218)

try:
    import xlwings as xw
    XLWINGS_AVAILABLE = True
    XLWINGS_IMPORT_ERROR = ""
except Exception as e:
    xw = None
    XLWINGS_AVAILABLE = False
    XLWINGS_IMPORT_ERROR = str(e)

def _need_xlwings():
    if not XLWINGS_AVAILABLE:
        raise RuntimeError(
            "xlwings를 불러오지 못했습니다. (열려있는 엑셀 모드 사용 불가)\n"
            f"상세: {XLWINGS_IMPORT_ERROR}\n"
            "해결: Excel 설치 확인 + pip로 xlwings 설치 + macOS 권한(Automation) 허용"
        )

def list_open_books():
    if not XLWINGS_AVAILABLE: return []
    try: return [b.name for b in xw.books]
    except: return []

def list_sheets(book_name):
    _need_xlwings()
    try: return [s.name for s in xw.books[book_name].sheets]
    except: return []

def _find_book(book_name):
    _need_xlwings()
    try: return xw.books[book_name]
    except Exception:
        raise Exception(f"엑셀 파일 '{book_name}'을 찾을 수 없습니다. 닫혔는지 확인하세요.")

def read_header_open(book_name, sheet_name, header_row):
    _need_xlwings()
    try:
        sht = xw.books[book_name].sheets[sheet_name]
        rng_val = sht.range((header_row, 1)).expand('right').value
        if rng_val is None: return []
        if not isinstance(rng_val, list): rng_val=[rng_val]
        return [str(c).strip() for c in rng_val if c is not None]
    except:
        return []

def read_table_open(book_name, sheet_name, header_row, usecols):
    b=_find_book(book_name); sht=b.sheets[sheet_name]
    all_header_val=sht.range((header_row,1)).expand('right').value
    if all_header_val is None: return pd.DataFrame()
    if not isinstance(all_header_val, list): all_header_val=[all_header_val]
    headers=[str(c).strip() if c else "" for c in all_header_val]
    start=header_row+1
    try:
        used=sht.used_range
        end_row=header_row + used.rows.count - 1
        end_col=max(len(headers), used.columns.count)
    except:
        end_row=header_row; end_col=len(headers)
    if end_row < start: return pd.DataFrame(columns=usecols)
    data=sht.range((start,1),(end_row,end_col)).value
    if data and not isinstance(data[0], list): data=[data]
    data=data or []
    if data and len(data[0])>len(headers): data=[row[:len(headers)] for row in data]
    df=pd.DataFrame(data, columns=headers)
    for c in usecols:
        if c not in df.columns: df[c]=""
    return df[usecols]

def write_to_open_excel(book_name, sheet_name, header_row, joined_df, take_cols, key_cols, use_color=False):
    try:
        b=_find_book(book_name); sht=b.sheets[sheet_name]; r=header_row
        try:
            h_val=sht.range((r,1)).expand('right').value
            last_col=1 if not isinstance(h_val,list) else len(h_val)
        except:
            last_col=1
        start_col=last_col+1
        sht.range((r,start_col)).value=take_cols
        sht.range((r,start_col),(r,start_col+len(take_cols)-1)).color=(255,255,200)
        matched_mask=joined_df[key_cols].notna().all(axis=1).to_numpy()
        vals=np.where(pd.isna(joined_df[take_cols].to_numpy()),"",joined_df[take_cols].to_numpy()).tolist()
        if vals:
            rng=sht.range((r+1,start_col),(r+len(vals),start_col+len(take_cols)-1))
            rng.value=vals
            if use_color:
                for i, ok in enumerate(matched_mask):
                    if ok:
                        sht.range((r+1+i,start_col),(r+1+i,start_col+len(take_cols)-1)).color=SUCCESS_COLOR
    except Exception as e:
        err=str(e)
        if "-2147352567" in err:
            raise Exception("⚠️ 엑셀이 편집 모드입니다. 셀 편집을 종료(Enter)하고 다시 실행하세요!")
        raise

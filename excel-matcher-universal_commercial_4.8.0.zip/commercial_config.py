# Commercial configuration
APP_EDITION = "Commercial"
COMMERCIAL_VERSION = "4.8.0"
LICENSE_FILE = "license.lic"
# Admin password to open license panel
ADMIN_PASSWORD = "0303"  # change before shipping

# Personal plan limits
PERSONAL_MAX_ROWS = 50000

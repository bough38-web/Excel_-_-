# FAQ

## Q. '열려있는 엑셀' 모드가 안 됩니다.
- Microsoft Excel 설치 필요
- xlwings 설치 필요
- macOS는 Automation(Apple Events) 권한 허용이 필요할 수 있음

## Q. 백신이 실행을 막아요.
- onefile보다 onedir(폴더형) 배포 권장
- 코드서명 적용 시 경고 감소

## Q. 결과 파일이 덮어써져요.
- 결과 파일명에 타임스탬프가 포함됩니다.

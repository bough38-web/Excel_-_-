
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pandas as pd
from engine.matcher_engine import MatcherEngine
from license_manager import validate_license
from admin_panel import AdminPanel
from config import APP_NAME, VERSION

class EnterpriseApp(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} v{VERSION}")
        self.geometry("700x450")

        valid, msg = validate_license()
        if not valid:
            messagebox.showerror("라이선스 오류", msg)
            self.destroy()
            return

        self.progress = ttk.Progressbar(self, length=600)
        self.progress.pack(pady=15)

        self.status = ttk.Label(self, text="Ready")
        self.status.pack()

        self.run_btn = ttk.Button(self, text="파일 매칭 실행", command=self.run_match)
        self.run_btn.pack(pady=10)

        ttk.Button(self, text="관리자", command=self.open_admin).pack()

    def update_progress(self, pct, msg):
        self.progress["value"] = pct
        self.status.config(text=f"{pct}% - {msg}")
        self.update_idletasks()

    def open_admin(self):
        AdminPanel(self)

    def run_match(self):
        messagebox.showinfo("안내", "실제 파일 매칭 로직 연결 가능")

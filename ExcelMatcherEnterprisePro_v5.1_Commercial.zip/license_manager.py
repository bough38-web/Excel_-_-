
import json, os, datetime
from config import LICENSE_FILE

def load_license():
    if not os.path.exists(LICENSE_FILE):
        return None
    with open(LICENSE_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def validate_license():
    lic = load_license()
    if not lic:
        return False, "라이선스 파일 없음"

    expiry = datetime.datetime.strptime(lic["expiry"], "%Y-%m-%d").date()
    today = datetime.date.today()

    if today > expiry:
        return False, "라이선스 만료"

    return True, lic["type"]

def generate_license(expiry_date, license_type="personal"):
    lic = {
        "expiry": expiry_date,
        "type": license_type
    }
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(lic, f)

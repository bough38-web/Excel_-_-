
import pandas as pd
from engine.performance_mode import select_mode

class MatcherEngine:

    def __init__(self, progress_callback=None):
        self.progress = progress_callback

    def _update(self, pct, msg):
        if self.progress:
            self.progress(pct, msg)

    def match(self, df_b, df_t, key_cols, take_cols):

        rows = max(len(df_b), len(df_t))
        mode = select_mode(rows)
        self._update(5, f"Mode: {mode}")

        sep = "||"

        if mode == "standard":
            df_b = df_b.set_index(key_cols)
            df_t = df_t.set_index(key_cols)
            result = df_b.join(df_t[take_cols], how="left").reset_index()
            self._update(90, "Complete")
            return result

        df_b["_key"] = df_b[key_cols].astype(str).agg(sep.join, axis=1)
        df_t["_key"] = df_t[key_cols].astype(str).agg(sep.join, axis=1)

        df_t = df_t.drop_duplicates("_key")

        mapping = {
            col: pd.Series(df_t[col].values, index=df_t["_key"])
            for col in take_cols
        }

        result = pd.DataFrame()

        for col in take_cols:
            result[col] = df_b["_key"].map(mapping[col]).fillna("")

        joined = pd.concat([df_b[key_cols], result], axis=1)
        self._update(95, "Complete")
        return joined

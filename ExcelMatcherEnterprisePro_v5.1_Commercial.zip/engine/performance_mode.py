
def select_mode(rows):
    if rows < 50000:
        return "standard"
    elif rows < 150000:
        return "hash"
    else:
        return "chunk"

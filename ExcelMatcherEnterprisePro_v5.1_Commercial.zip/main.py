
from ui import EnterpriseApp

if __name__ == "__main__":
    app = EnterpriseApp()
    app.mainloop()

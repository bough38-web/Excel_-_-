
import tkinter as tk
from tkinter import ttk, messagebox
from license_manager import generate_license

class AdminPanel(tk.Toplevel):

    def __init__(self, parent):
        super().__init__(parent)
        self.title("관리자 패널")
        self.geometry("300x250")

        ttk.Label(self, text="만료일 (YYYY-MM-DD)").pack(pady=5)
        self.expiry = ttk.Entry(self)
        self.expiry.pack()

        ttk.Label(self, text="라이선스 타입").pack(pady=5)
        self.type_var = tk.StringVar(value="personal")
        ttk.Combobox(self, textvariable=self.type_var, values=["personal","enterprise"]).pack()

        ttk.Button(self, text="라이선스 생성", command=self.create).pack(pady=10)

    def create(self):
        generate_license(self.expiry.get(), self.type_var.get())
        messagebox.showinfo("완료", "라이선스 생성 완료")

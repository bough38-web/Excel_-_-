import sys
import datetime
import tkinter as tk
from tkinter import messagebox, ttk
from ui import App
from __version__ import __version__

PASSWORD = "0303"
EXPIRY_DATE = datetime.date(2026, 2, 28)

def show_login_dialog(root_app):
    login_win = tk.Toplevel(root_app)
    login_win.title("로그인")

    w, h = 360, 230
    ws = root_app.winfo_screenwidth()
    hs = root_app.winfo_screenheight()
    x = (ws // 2) - (w // 2)
    y = (hs // 2) - (h // 2)
    login_win.geometry(f"{w}x{h}+{x}+{y}")
    login_win.resizable(False, False)

    login_win.attributes('-topmost', True)
    login_win.grab_set()
    login_win.focus_force()

    def on_close():
        root_app.destroy()
        sys.exit()
    login_win.protocol("WM_DELETE_WINDOW", on_close)

    style = ttk.Style(login_win)
    try: style.theme_use('clam')
    except: pass

    frame = ttk.Frame(login_win, padding=20)
    frame.pack(fill="both", expand=True)

    ttk.Label(frame, text=f"🔒 Excel 매칭 도구 v{__version__}", font=("맑은 고딕", 14, "bold"), foreground="#333").pack(pady=(5, 15))
    ttk.Label(frame, text="비밀번호를 입력하세요:", font=("맑은 고딕", 10)).pack(anchor="w")

    pw_var = tk.StringVar()
    entry = ttk.Entry(frame, textvariable=pw_var, show="*", font=("맑은 고딕", 11))
    entry.pack(fill="x", pady=5, ipady=3)
    entry.focus()

    def validate(event=None):
        if pw_var.get() == PASSWORD:
            login_win.destroy()
            root_app.deiconify()
            root_app.lift()
            root_app.attributes('-topmost', True)
            root_app.after(800, lambda: root_app.attributes('-topmost', False))
        else:
            messagebox.showerror("오류", "비밀번호가 일치하지 않습니다.", parent=login_win)
            pw_var.set("")
            entry.focus()

    entry.bind("<Return>", validate)
    ttk.Button(frame, text="확인", command=validate).pack(fill="x", pady=15, ipady=5)

    root_app.wait_window(login_win)

def check_expiry():
    today = datetime.date.today()
    if today > EXPIRY_DATE:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("기간 만료", f"사용 기간({EXPIRY_DATE})이 종료되었습니다.\n개발자에게 문의하세요.")
        root.destroy()
        return False
    return True

if __name__ == "__main__":
    if not check_expiry():
        sys.exit()
    app = App()
    app.withdraw()
    show_login_dialog(app)
    app.mainloop()

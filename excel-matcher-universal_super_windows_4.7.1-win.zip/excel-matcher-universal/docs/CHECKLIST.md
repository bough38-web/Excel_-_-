# 배포 체크리스트 (Windows)

## 공통
- 버전(__version__.py) 업데이트
- 파일 모드 매칭 테스트(샘플 or 실제 데이터)
- open-excel 모드 테스트(Excel 설치 PC)

## Windows
- 코드서명 적용(권장)
- SmartScreen/백신 대응 문구 준비(FAQ)
- GitHub Actions 태그 기반 릴리즈 정상 동작 확인

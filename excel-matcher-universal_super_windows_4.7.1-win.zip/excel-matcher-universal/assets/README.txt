아이콘: assets/app.ico(Windows), assets/app.icns(macOS) 추가 가능
